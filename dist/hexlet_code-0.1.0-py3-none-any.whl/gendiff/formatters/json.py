import json


def make_json(diff):
    return json.dumps(diff)
